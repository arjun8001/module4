package com.trainee.exception;

public class TraineeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2429005644596060387L;

	public TraineeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
