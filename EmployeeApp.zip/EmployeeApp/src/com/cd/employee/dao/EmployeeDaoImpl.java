package com.cd.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cd.employee.bean.EmployeeBean;
import com.cd.employee.exception.EmployeeException;
import com.cd.employee.util.DbConnection;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	
	@Override
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		int result = 0;
		boolean isInserted=false;
		try {
			conn = DbConnection.getConnection();
			
			preparedStatement = conn.prepareStatement(IQuerryMapperDao.INSERT_EMPLOYEE);
			
			preparedStatement.setInt(1, employeeBean.getEmpId());
			preparedStatement.setString(2, employeeBean.getEmpName());
			preparedStatement.setDate(3, Date.valueOf(employeeBean.getEmpDob()));
			preparedStatement.setDouble(4,employeeBean.getSalary());
			preparedStatement.setString(5, employeeBean.getDesignation());
			
			result = preparedStatement.executeUpdate();
			if(result>0)
			{
				isInserted=true;
			}
			conn.close();
		} catch (EmployeeException e) {
			throw new EmployeeException("In Dao Layer Insert Employee Method"+e.getMessage());
			
		} catch (SQLException e) {
			throw new EmployeeException("In Dao Layer Insert Employee Method"+e.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public EmployeeBean getEmployee(int empid) throws EmployeeException {
		EmployeeBean bean = new EmployeeBean();
		
		try {
			conn = DbConnection.getConnection();
			
			preparedStatement = conn.prepareStatement(IQuerryMapperDao.VIEW_EMPLOYEE);
			
			preparedStatement.setInt(1, empid);
			resultSet = preparedStatement.executeQuery();
			if(resultSet==null){
				throw new EmployeeException("Invalid Employee ID");
			}
			while(resultSet.next()){
				bean.setEmpId(resultSet.getInt(1));
				bean.setEmpName(resultSet.getString(2));
				bean.setEmpDob(resultSet.getDate(3).toLocalDate());
				bean.setSalary(resultSet.getDouble(4));
				bean.setDesignation(resultSet.getString(5));
			}
			if(resultSet==null){
				throw new EmployeeException("Invalid Employee ID");
			}
			conn.close();
		} catch (EmployeeException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
			
		} catch (SQLException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
		}
		return bean;
	}

	@Override
	public List<EmployeeBean> getAllEmployee() throws EmployeeException {
		List<EmployeeBean> list = new ArrayList<EmployeeBean>();
		
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapperDao.VIEWALL_EMPLOYEE);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				EmployeeBean bean = new EmployeeBean();
				bean.setEmpId(resultSet.getInt(1));
				bean.setEmpName(resultSet.getString(2));
				bean.setEmpDob(resultSet.getDate(3).toLocalDate());
				bean.setSalary(resultSet.getDouble(4));
				bean.setDesignation(resultSet.getString(5));
				list.add(bean);
			}
			conn.close();
		} catch (EmployeeException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
			
		} catch (SQLException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
		}
		
		return list;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException {
		boolean isDeleted = false;
		int dele = 0;
		
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapperDao.DELETE_EMPLOYEE);
			preparedStatement.setInt(1, empid);
			
			dele = preparedStatement.executeUpdate();
			
			if(dele > 0){
				isDeleted = true;
			}
		} catch (EmployeeException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
			
		} catch (SQLException e) {
			throw new EmployeeException("In Dao Layer getEmployee Method"+e.getMessage());
		}
		return isDeleted;
	}

}

