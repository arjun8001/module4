package com.cd.employee.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cd.employee.bean.EmployeeBean;
import com.cd.employee.exception.EmployeeException;
import com.cd.employee.service.EmployeeServiceImpl;
import com.cd.employee.service.IEmployeeService;

/**
 * Servlet implementation class EmployeeServlet2
 */

@WebServlet("*.obj")
public class EmployeeServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet2() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IEmployeeService empService = new EmployeeServiceImpl();
		EmployeeBean empBean = new EmployeeBean();
		
		String target = "";

		HttpSession session = request.getSession(true);
		// Object creations

		
		String TargetInsert		 = "/pages/insertEmployee.jsp";
		String TargetSuccess	 = "/pages/success.jsp";
		String targetSearch 	 = "/pages/searchEmployee.jsp";
		String targetViewAll 	 = "/pages/viewAllEmployees.jsp";
		String targetError       = "/pages/error.jsp";
		String targetHome        = "index.jsp";
		
		
		String path = request.getServletPath().trim();
		
		switch(path){
		
		case "/Home.obj" :
			session.setAttribute("error", null);
			session.setAttribute("employee", null);
			target = "index.jsp";
			break;
			
		case "/add.obj":
			target=TargetInsert;
			break;
		
		case "/insert.obj":
			//String da = request.getParameter("dob")
			try {
				empBean.setEmpId(Integer.parseInt(request.getParameter("empId")));
				empBean.setEmpName(request.getParameter("empName"));
				
				DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate ld=LocalDate.parse(request.getParameter("empDob"), formatter);
				
				empBean.setDesignation(request.getParameter("designation"));
				empBean.setEmpDob(ld);
				empBean.setSalary(Double.parseDouble(request.getParameter("salary")));
				boolean inserted=empService.insertEmployee(empBean);
				if(inserted){
					target=TargetSuccess;
				}
			} catch (NumberFormatException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
			} catch (EmployeeException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
	
			}
			
			break;
		case "/viewAll.obj" :
			try {
				List<EmployeeBean> list = empService.getAllEmployee();
				session.setAttribute("employees", list);
				target=targetViewAll;
			} catch (EmployeeException e) {
				
				e.printStackTrace();
			}
			break;
		case "/search.obj" :
			target=targetSearch;
			
		break;
		
		case "/searchEmployee.obj" :
			
			try {
				empBean = empService.getEmployee(Integer.parseInt(request.getParameter("empId")));
				List<EmployeeBean> list2 = new ArrayList<EmployeeBean>();
				list2.add(empBean);
				session.setAttribute("employees", list2);
				target=targetViewAll;
			} catch (NumberFormatException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
			} catch (EmployeeException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
			}
			
			break;
			
		case "/delete.obj" :
			target="delete.jsp";
			break;
			
		case "/deleteEmployee.obj" :
			try {
				empService.deleteEmployee(Integer.parseInt(request.getParameter("empId")));
				target=TargetSuccess;
			} catch (NumberFormatException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
			} catch (EmployeeException e) {
				target = targetError;
				request.setAttribute("message", e.getMessage());
			}
			
			break;
			
		}
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	}

}
