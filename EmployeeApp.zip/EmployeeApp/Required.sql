CREATE TABLE EMPLOY (empid number, empname varchar2(30), empDob date, salary number(5,2), designation varchar2(20));
